#include <Eigen/Sparse>
#include <iostream>
#include <fstream>

using namespace Eigen;
using namespace std;


/**
 * Creates a list of rectangles, where each rectangle is defined by the indices of its four nodes.
 * The output is a vector of size (number_of_rectangles × 4), where each row represents a rectangle.
 * 
 * @param number_of_points The number of mesh points in one fourth of the mesh.
 * @return A vector containing lists of four node indices forming each rectangle.
 */
std::vector<std::vector<int>> create_rectangle_and_mesh(int number_of_points) {

    Eigen::MatrixXi mesh = Eigen::MatrixXi::Zero(number_of_points, number_of_points);
    
    int count = 0;
    for (int i = 0; i < number_of_points; ++i) {
        for (int j = 0; j < number_of_points; ++j) {
            mesh(i, j) = count++;
        }
    }

    std::vector<std::vector<int>> rectangles;
    for (int i = 1; i < number_of_points; ++i) {
        for (int j = 0; j < number_of_points - 1; ++j) {
            std::vector<int> line = {
                mesh(i, j),
                mesh(i, j + 1),
                mesh(i - 1, j + 1),
                mesh(i - 1, j)
            };
            rectangles.push_back(line);
        }
    }

    return rectangles;
}


/**
 * Generates a list of coordinates for mesh points in one-fourth of the domain.
 * The output is a matrix of size (number_of_points² × 2), where each row represents a (x, y) coordinate.
 *
 * @param L The length of the chip.
 * @param number_of_points The number of mesh points in one fourth of the mesh.
 * @return An Eigen matrix of size (number_of_points² × 2) containing the coordinates.
 */
Eigen::MatrixXd create_coordinates(double L, int number_of_points) {
    Eigen::MatrixXd coordinates(number_of_points * number_of_points, 2);
    double h = (L / 2.0) / (number_of_points - 1);

    for (int i = 0; i < number_of_points; ++i) {
        for (int j = 0; j < number_of_points; ++j) {
            coordinates(i * number_of_points + j, 0) = j * h; // x-coordinate
            coordinates(i * number_of_points + j, 1) = i * h; // y-coordinate
        }
    }

    return coordinates;
}

std::vector<Eigen::Vector3d> filter_boundary_points_with_index(const Eigen::MatrixXd& coordinates, double L, double lower = 0.003, double upper = 0.007) {
    /**
     * Creates a list of boundary points with their indices.
     * Each boundary point is stored as a 3D vector (index, x, y).
     * 
     * @param coordinates: Matrix (N x 2) containing the (x, y) coordinates.
     * @param L: The length of the chip.
     * @param lower: Lower bound for y values.
     * @param upper: Upper bound for y values.
     * @return A vector of Eigen::Vector3d where each entry contains (index, x, y).
     */
    
    std::vector<Eigen::Vector3d> boundary_points;
    
    for (int idx = 0; idx < coordinates.rows(); ++idx) {
        double x = coordinates(idx, 0);
        double y = coordinates(idx, 1);

        if ((x == 0 || x == L) && (lower <= y && y <= upper)) {
            boundary_points.emplace_back(idx, x, y);
        }
    }

    return boundary_points;
}

Eigen::VectorXd fill_in_k(const Eigen::VectorXd& v, double k_max, double k_min, double p) {
    /**
     * Computes the material property values (k) based on the density vector (v).
     * 
     * @param v: Vector of densities (values between 0 and 1).
     * @param k_max: Maximum stiffness value.
     * @param k_min: Minimum stiffness value.
     * @param p: Penalization factor.
     * @return Eigen::VectorXd containing computed k values.
     */

    Eigen::VectorXd k(v.size());

    for (int i = 0; i < v.size(); ++i) {
        k(i) = k_min + (k_max - k_min) * std::pow(v(i), p);
    }

    return k;
}



Eigen::SparseMatrix<double> find_K(
    const Eigen::VectorXd& v,
    std::vector<std::vector<int>> rectangles,
    int number_of_points,
    const Eigen::Matrix4d& local_matrix,
    double k_min,
    double k_max,
    double penal
) {
    using T = Eigen::Triplet<double>;
    std::vector<T> triplets;

    Eigen::VectorXd k_values = k_min + (k_max - k_min) * v.array().pow(penal);

    int size = number_of_points * number_of_points;
    Eigen::SparseMatrix<double> K(size, size);

    for (size_t e = 0; e < rectangles.size(); ++e) {
        double k_e = k_values[e];

        for (int l = 0; l < 4; ++l) {
            for (int m = 0; m < 4; ++m) {
                int index_i = rectangles[e][l];
                int index_j = rectangles[e][m];
                double value = local_matrix(l, m);

                triplets.emplace_back(index_i, index_j, k_e * value);
            }
        }
    }

    K.setFromTriplets(triplets.begin(), triplets.end());
    return K;
}


Eigen::VectorXd find_F(std::vector<std::vector<int>> rectangles, int number_of_points, double L) {
    double h = (L / 2) / (number_of_points - 1);
    Eigen::VectorXd F = Eigen::VectorXd::Zero(number_of_points * number_of_points);
    
    for (const auto& rectangle : rectangles) {
        double F_local = (h * h) * (10e6) / 4.;
        
        for (int l = 0; l < 4; ++l) {
            int index_i = rectangle[l];
            F(index_i) += F_local;
        }
    }

    return F;
}


std::pair<Eigen::SparseMatrix<double>, Eigen::VectorXd> apply_boundary(Eigen::SparseMatrix<double>& K, Eigen::VectorXd& F, std::vector<Eigen::Vector3d> boundary_points, double T_k) {
    for (const auto& point : boundary_points) {
        int index_of_point = point[0];
        F -= T_k * K.col(index_of_point);  // Soustraction du terme de force local

        // Mise à zéro des coefficients de la matrice K associés au point de bordure
        for (int i = 0; i < K.rows(); ++i) {
            K.coeffRef(i, index_of_point) = 0;
            K.coeffRef(index_of_point, i) = 0;
        }

        K.coeffRef(index_of_point, index_of_point) = 1; // Diagonal égale à 1
        F(index_of_point) = T_k; // Force au point de bordure
    }

    return {K, F};
}


double objective(const Eigen::VectorXd& v, const std::vector<std::vector<int>>& rectangles, 
    const Eigen::VectorXd& T, const Eigen::Matrix4d& K0, 
    double k_min, double k_max, double p) {
    /**
    * Computes the objective function value for a given material distribution.
    * 
    * @param v: Density vector (values between 0 and 1).
    * @param rectangles: List of elements, each defined by 4 node indices.
    * @param T: Temperature values at each node.
    * @param K0: Base stiffness matrix (4x4) stored as a sparse matrix.
    * @param k_min: Minimum stiffness value.
    * @param k_max: Maximum stiffness value.
    * @param p: Penalization factor.
    * @return Computed objective function value.
    */

    double D = 0.0;
    Eigen::VectorXd k_values = fill_in_k(v, k_max, k_min, p);

    for (size_t e = 0; e < rectangles.size(); ++e) {
    double k_e = k_values(e);

    // Extraction de T_loc (4x1)
    Eigen::VectorXd T_loc(4);
    for (int l = 0; l < 4; ++l) {
    T_loc(l) = T(rectangles[e][l]);
    }

    // Calcul du produit K * T_loc en utilisant SparseMatrix
    Eigen::VectorXd K_T_loc = k_e * K0 * T_loc;

    // Mise à jour de D avec le produit scalaire (T_loc^T * K * T_loc)
    D += T_loc.transpose() * K_T_loc;
    }

return D;
}


Eigen::VectorXd adjoint(const Eigen::VectorXd& T, const Eigen::VectorXd& v, 
    const std::vector<std::vector<int>>& corners, 
    const Eigen::MatrixXd& K0, double p = 3) {
    /**
    * Compute the derivative of the cost function with respect to the fraction of metal for each element.
    * 
    * @param T: The global temperature vector.
    * @param v: The global vector with fractions of metal in each element.
    * @param corners: A nested list with first index as elements and second index as the nodes of each element.
    * @param K0: The local stiffness matrix (4x4).
    * @param p: Penalization factor that pushes fractions of metal towards 0 or 1 (p > 1).
    * @return gradJv: A column vector of size(n) containing the derivative of the cost function.
    */

    int elements = v.size();
    Eigen::VectorXd gradJv(elements);
    double km = 65;
    double kp = 0.2;

    for (int el = 0; el < elements; ++el) {
        const std::vector<int>& elementNodes = corners[el];
        Eigen::VectorXd Te(4); // Assuming each element has 4 nodes
        for (int i = 0; i < 4; ++i) {
            Te(i) = T(elementNodes[i]);
        }

        // Compute the derivative (using Eigen matrix and vector operations)
        gradJv(el) = -0.5 * p * std::pow(v(el), p - 1) * (km - kp) * (Te.transpose() * K0 * Te)(0, 0);
    }

    return gradJv;
}

void createSparseMatrix(int nx, int ny, const vector<int>& iH, const vector<int>& jH, const vector<double>& sH, SparseMatrix<double>& H, VectorXd& Hs) {
    int N = nx * ny;
    vector<Triplet<double>> tripletList;

    for (size_t k = 0; k < sH.size(); ++k) {
        tripletList.emplace_back(iH[k], jH[k], sH[k]);
    }

    H.resize(N, N);
    H.setFromTriplets(tripletList.begin(), tripletList.end());

    // Compute sum of each row
    Hs = VectorXd::Zero(N);
    for (int k = 0; k < H.outerSize(); ++k) {
        for (SparseMatrix<double>::InnerIterator it(H, k); it; ++it) {
            Hs(it.row()) += it.value();
        }
    }
}


Eigen::VectorXd optimize(const Eigen::MatrixXd& K0, double max_vol_frac, 
    int nx, int ny,double penal,const std::vector<std::vector<int>>& rectangles, double L,
    double boundary_temp, int ft) {

        double E_min = 0.2;
        double E_0 = 65;
        double rmin  = 0.04*nx;

        int N_total_elements = nx * ny;
        int N_total_points = (nx + 1) * (ny + 1);
        int N_points_1D = nx + 1;

        std::vector<int> iH, jH;
        std::vector<double> sH;

        for (int i1 = 0; i1 < nx; ++i1) {
            for (int j1 = 0; j1 < ny; ++j1) {
                int e1 = i1 * ny + j1;
                for (int i2 = std::max(i1 - static_cast<int>(std::ceil(rmin)) + 1, 0); i2 < std::min(i1 + static_cast<int>(std::ceil(rmin)), nx); ++i2) {
                    for (int j2 = std::max(j1 - static_cast<int>(std::ceil(rmin)) + 1, 0); j2 < std::min(j1 + static_cast<int>(std::ceil(rmin)), ny); ++j2) {
                        int e2 = i2 * ny + j2;
                        double weight = std::max(0.0, rmin - std::sqrt((i1 - i2) * (i1 - i2) + (j1 - j2) * (j1 - j2)));
                        iH.push_back(e1);
                        jH.push_back(e2);
                        sH.push_back(weight);
                    }
                }
            }
        }

        SparseMatrix<double> H;
        VectorXd Hs;
        createSparseMatrix(nx, ny, iH, jH, sH, H, Hs);


        VectorXd x = VectorXd::Constant(nx * ny, max_vol_frac);
        VectorXd xPhys = x;
        int loop = 0 ;
        double change = 1;
        Eigen::MatrixXd coordinates = create_coordinates(L,N_points_1D);
        std::vector<Eigen::Vector3d> boundary_points = filter_boundary_points_with_index(coordinates,L);

        while(change>0.01 && loop<500){
            loop++;

            Eigen::SparseMatrix<double> K = find_K(xPhys, rectangles, N_points_1D, K0, 0.2, 65.0, penal);
            Eigen::VectorXd F = find_F(rectangles,N_points_1D,L);

            auto result = apply_boundary(K, F, boundary_points, boundary_temp);
            K = result.first;
            F = result.second;


            Eigen::ConjugateGradient<Eigen::SparseMatrix<double>, Eigen::Lower | Eigen::Upper> solver;
            solver.compute(K);  
        
            solver.setMaxIterations(1000);
            solver.setTolerance(1e-4);
        
            Eigen::VectorXd U = solver.solve(F); 

            double c = objective(xPhys,rectangles,U,K0,0.2,65,penal);
            Eigen::VectorXd dc = adjoint(U,xPhys,rectangles,K0,penal);

            VectorXd dv = VectorXd::Ones(dc.size());

            if (ft == 1) { 
                dc = H * (x.array() * dc.array()).matrix();
                dc = dc.array() / (Hs.array().max(1e-3));
            }else if (ft == 2) { // Density filtering
                dc = H * (dc.array() / Hs.array()).matrix();
                dv = H * (dv.array() / Hs.array()).matrix();
            }


            double l1 = 0;
            double l2 = 1e9;
            double move = 0.3;
            Eigen::VectorXd xnew = Eigen::VectorXd::Zero(x.size());
            while((l2-l1)/(l2+l1)>0.001){

                double lmid = 0.5*(l1+l2);
                VectorXd B = (-dc.array() / (dv.array() * lmid)).max(0).sqrt(); 
                VectorXd Bx = B.array() * x.array(); 




                xnew = Eigen::VectorXd::Zero(x.size());
                for (int e = 0; e < x.size(); ++e) {
                    if (Bx[e] <= std::max(0.0, x[e] - move)) {
                        xnew[e] = std::max(0.0, x[e] - move);
                    } else if (Bx[e] >= std::min(1.0, x[e] + move)) {
                        xnew[e] = std::min(1.0, x[e] + move);
                    } else {
                        xnew[e] = Bx[e];
                    }
                }


                for (size_t i = 0; i < x.size(); ++i) {
                    double x_val = x[i];
                    double B_val = B[i];

                    // Calcul de la valeur de xnew[i]
                    double max_x_move = std::max(x_val - move, 0.0);
                    double min_x_move = std::min(x_val + move, 1.0);
                    double x_times_B = x_val * B_val;

                    if (max_x_move > x_times_B) {
                        xnew[i] = std::max(max_x_move, 0.0);
                    } else if (min_x_move < x_times_B) {
                        xnew[i] = std::min(min_x_move, 1.0);
                    } else {
                        xnew[i] = x_times_B;
                    }

                    xnew[i] = std::max(xnew[i], 0.0);
                }
    

                if (ft == 0 || ft == 1) {
                    xPhys = xnew;
                } else if (ft == 2) {
                    xPhys = H * xnew; 
                    xPhys = xPhys.cwiseQuotient(Hs);  
                }

                if (xPhys.sum() > max_vol_frac * nx * nx) {
                    l1 = lmid;
                } else {
                    l2 = lmid;
                }
            }
        change = (xnew - x).cwiseAbs().maxCoeff();
        x = xnew;
        std::cout << "It.: " << loop << " Obj.: " << c << " Vol.: " << xPhys.mean() << " ch.: " << change << std::endl;   
        }

        return x;
    }












void save_result_to_file(const Eigen::VectorXd& U, const std::string& filename) {
    std::ofstream file(filename);  // Ouvre un fichier pour écrire
    if (file.is_open()) {
        for (int i = 0; i < U.size(); ++i) {
            file << U(i) << std::endl;  // Écrit chaque valeur de U dans le fichier
        }
        file.close();  // Ferme le fichier après l'écriture
        std::cout << "Saved" << filename << std::endl;
    } else {
        std::cerr << "Not saved"<< filename << std::endl;
    }
}




int main() {
    double  L = 0.01;
    int p = 3;
    double T_k  = 293;
    int number_of_points = 100;

    Eigen::Matrix4d local_matrix; 
    local_matrix <<  2.0/3, -1.0/6, -1.0/3, -1.0/6,
                    -1.0/6,  2.0/3, -1.0/6, -1.0/3,
                    -1.0/3, -1.0/6,  2.0/3, -1.0/6,
                    -1.0/6, -1.0/3, -1.0/6,  2.0/3;


    std::vector<std::vector<int>> rectangles = create_rectangle_and_mesh(number_of_points);
    Eigen::VectorXd x = optimize(local_matrix,0.4,number_of_points-1,number_of_points-1,p,rectangles,L,293,2);


    save_result_to_file(x,"x.txt");
    
    
    return 0;
}